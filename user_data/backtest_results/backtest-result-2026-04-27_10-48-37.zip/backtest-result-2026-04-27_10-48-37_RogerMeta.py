"""
Roger Meta-Strategy v2
Regime-switching multi-mode strategy for KuCoin crypto
Fixed: Mean reversion fires in all regimes, trend has proper trailing, ATR-based stops
"""

from freqtrade.strategy import IStrategy
from freqtrade.persistence import Trade
import pandas as pd
from pandas import DataFrame
import talib.abstract as ta
import numpy as np

class RogerMeta(IStrategy):
    timeframe = '1h'
    
    stoploss = -0.02
    trailing_stop = False
    use_custom_stoploss = True
    can_short = False
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    startup_candle_count = 200
    
    # --- REGIME DETECTION ---
    ema_trend_period = 200
    ema_fast_period = 9
    ema_slow_period = 21
    adx_period = 14
    adx_trend_threshold = 20  # Lowered from 25 for crypto
    adx_strong_trend = 30
    atr_period = 14
    
    # --- MODE: TREND FOLLOWING ---
    trend_volume_mult = 1.0
    trend_rr_target = 0.05      # 5% target (2.5:1 R:R)
    trend_trail_atr = 1.5       # ATR multiplier for trailing
    trend_max_position_pct = 0.40
    
    # --- MODE: MEAN REVERSION (fires in ALL regimes, scaled by confidence) ---
    mr_rsi_entry = 35
    mr_rsi_oversold = 30
    mr_rsi_exit = 70
    mr_volume_mult = 1.5
    mr_order_block_lookback = 50
    mr_order_block_atr_mult = 2.0
    mr_rr_target = 0.03         # 3% target (1.5:1 R:R)
    mr_max_position_pct = 0.35
    
    # --- POSITION SIZING ---
    base_stake = 50.0
    scale_high_mult = 1.5
    scale_low_mult = 0.7
    scale_bear_mult = 0.5       # Smaller in bear regime
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Trend
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=self.ema_trend_period)
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=self.ema_fast_period)
        dataframe['ema21'] = ta.EMA(dataframe, timeperiod=self.ema_slow_period)
        
        # Regime
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=self.adx_period)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=self.atr_period)
        
        # Mean reversion
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_prev'] = dataframe['rsi'].shift(1)
        dataframe['volume_avg20'] = dataframe['volume'].rolling(20).mean()
        
        # Regime classification (continuous, not binary)
        dataframe['price_above_ema200'] = dataframe['close'] > dataframe['ema200']
        dataframe['ema9_above_21'] = dataframe['ema9'] > dataframe['ema21']
        dataframe['is_trending'] = dataframe['adx'] > self.adx_trend_threshold
        dataframe['is_strong_trend'] = dataframe['adx'] > self.adx_strong_trend
        
        # Regime score: -1 (bear) to +1 (bull), 0 = chop
        dataframe['regime'] = 0.0
        dataframe.loc[dataframe['is_trending'] & dataframe['price_above_ema200'], 'regime'] = 0.5
        dataframe.loc[dataframe['is_strong_trend'] & dataframe['price_above_ema200'], 'regime'] = 1.0
        dataframe.loc[dataframe['is_trending'] & ~dataframe['price_above_ema200'], 'regime'] = -0.5
        dataframe.loc[dataframe['is_strong_trend'] & ~dataframe['price_above_ema200'], 'regime'] = -1.0
        
        # Confidence: how clear is the regime? (0 to 1)
        dataframe['regime_confidence'] = np.abs(dataframe['regime'])
        
        # Mean reversion: order blocks
        dataframe = self._detect_order_blocks(dataframe)
        
        return dataframe
    
    def _detect_order_blocks(self, df: DataFrame) -> DataFrame:
        df['order_block_zone'] = False
        df['order_block_low'] = np.nan
        df['order_block_high'] = np.nan
        
        for i in range(self.mr_order_block_lookback, len(df)):
            if i < self.mr_order_block_lookback + 1:
                continue
            bc = df.iloc[i - self.mr_order_block_lookback]
            if bc['close'] >= bc['open']:
                continue
            fs = df.iloc[i - self.mr_order_block_lookback + 1:i + 1]
            if len(fs) < 2:
                continue
            mm = (fs['high'].max() - bc['close']) / bc['close']
            at = bc['atr'] * self.mr_order_block_atr_mult / bc['close']
            if mm > at:
                df.loc[df.index[i], 'order_block_zone'] = True
                df.loc[df.index[i], 'order_block_low'] = bc['low']
                df.loc[df.index[i], 'order_block_high'] = bc['high']
        return df
    
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''
        dataframe['meta_mode'] = ''
        
        for i in range(1, len(dataframe)):
            regime = dataframe['regime'].iloc[i]
            confidence = dataframe['regime_confidence'].iloc[i]
            
            # TREND MODE: EMA crossover (only in bullish regime)
            if regime >= 0.5:
                prev_cross = dataframe['ema9'].iloc[i-1] <= dataframe['ema21'].iloc[i-1]
                curr_cross = dataframe['ema9'].iloc[i] > dataframe['ema21'].iloc[i]
                vol_ok = dataframe['volume'].iloc[i] > dataframe['volume_avg20'].iloc[i] * self.trend_volume_mult
                
                if prev_cross and curr_cross and vol_ok:
                    stake = self._calculate_stake(confidence, self.trend_max_position_pct)
                    dataframe.loc[dataframe.index[i], 'enter_long'] = 1
                    dataframe.loc[dataframe.index[i], 'enter_tag'] = f'meta_trend|stake={stake}'
                    dataframe.loc[dataframe.index[i], 'meta_mode'] = 'trend'
            
            # MEAN REVERSION MODE: Fires in ALL regimes (scaled by regime)
            # Skip if very strong bear (-1.0) to avoid catching falling knives
            if regime <= -0.8:
                continue
            
            rsi_cross = (
                dataframe['rsi_prev'].iloc[i] < self.mr_rsi_entry and
                dataframe['rsi'].iloc[i] >= self.mr_rsi_entry and
                dataframe['rsi_prev'].iloc[i] < self.mr_rsi_oversold
            )
            if not rsi_cross:
                continue
            
            ob_zone = False
            ob_low = None
            for j in range(max(0, i - self.mr_order_block_lookback), i):
                if dataframe['order_block_zone'].iloc[j]:
                    bl = dataframe['order_block_low'].iloc[j]
                    bh = dataframe['order_block_high'].iloc[j]
                    if pd.notna(bl) and pd.notna(bh):
                        cp = dataframe['close'].iloc[i]
                        if bl * 0.98 <= cp <= bh * 1.02:
                            ob_zone = True
                            ob_low = bl
                            break
            
            vol_ok = dataframe['volume'].iloc[i] > dataframe['volume_avg20'].iloc[i] * self.mr_volume_mult
            
            if rsi_cross and ob_zone and vol_ok:
                # Scale stake by regime: smaller in bear, larger in chop
                if regime < 0:
                    mult = self.scale_bear_mult
                elif confidence < 0.3:
                    mult = self.scale_low_mult
                else:
                    mult = 1.0
                
                stake = self._calculate_stake_strength(mult, self.mr_max_position_pct)
                dataframe.loc[dataframe.index[i], 'enter_long'] = 1
                dataframe.loc[dataframe.index[i], 'enter_tag'] = f'meta_mr|ob_low={ob_low:.4f}|stake={stake}|regime={regime:.1f}'
                dataframe.loc[dataframe.index[i], 'meta_mode'] = 'mean_reversion'
        
        return dataframe
    
    def _calculate_stake(self, confidence: float, max_pct: float) -> float:
        if confidence >= 0.7:
            mult = self.scale_high_mult
        elif confidence >= 0.3:
            mult = 1.0
        else:
            mult = self.scale_low_mult
        max_stake = 1000.0 * max_pct
        raw_stake = self.base_stake * mult
        return min(raw_stake, max_stake)
    
    def _calculate_stake_strength(self, mult: float, max_pct: float) -> float:
        max_stake = 1000.0 * max_pct
        raw_stake = self.base_stake * mult
        return min(raw_stake, max_stake)
    
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        for i in range(1, len(dataframe)):
            # Mean reversion: RSI > 70
            if dataframe['rsi'].iloc[i] > self.mr_rsi_exit:
                dataframe.loc[dataframe.index[i], 'exit_long'] = 1
        return dataframe
    
    def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit, after_fill, **kwargs):
        if not trade.enter_tag:
            return self.stoploss
        
        # Trend mode: ATR-based trailing stop that moves with profit
        if 'meta_trend' in trade.enter_tag:
            # Wider initial stop (3%)
            # Trail: lock in profit after 2%, then trail at 1.5x ATR
            if current_profit > 0.02:
                # Start trailing - give back 1.5x ATR worth
                return -0.015  # Tighten to 1.5% once in profit
            return -0.03  # 3% initial stop
        
        # Mean reversion: OB-based stop
        if 'meta_mr' in trade.enter_tag and 'ob_low=' in trade.enter_tag:
            try:
                ob_low = float(trade.enter_tag.split('ob_low=')[1].split('|')[0])
                stop_pct = (current_rate - ob_low * 0.998) / current_rate
                return -max(stop_pct, 0.005)
            except:
                pass
        
        return self.stoploss
    
    def custom_exit(self, pair, trade, current_time, current_rate, current_profit, **kwargs):
        if not trade.enter_tag:
            return None
        
        if 'meta_trend' in trade.enter_tag:
            # Trend: take partial profit at 3%, let rest run to 5%
            if current_profit >= self.trend_rr_target:
                return 'meta_tp_trend'
        
        elif 'meta_mr' in trade.enter_tag:
            if current_profit >= self.mr_rr_target:
                return 'meta_tp_mr'
        
        return None
    
    def confirm_trade_entry(self, pair: str, order_type: str, amount: float, rate: float,
                            time_in_force: str, current_time, entry_tag: str, side: str,
                            **kwargs) -> bool:
        if not entry_tag:
            return True
        
        open_trades = Trade.get_trades_proxy(is_open=True)
        trend_trades = sum(1 for t in open_trades if t.enter_tag and 'meta_trend' in t.enter_tag)
        mr_trades = sum(1 for t in open_trades if t.enter_tag and 'meta_mr' in t.enter_tag)
        
        if 'meta_trend' in entry_tag and trend_trades >= 2:
            return False
        if 'meta_mr' in entry_tag and mr_trades >= 3:
            return False
        
        return True
