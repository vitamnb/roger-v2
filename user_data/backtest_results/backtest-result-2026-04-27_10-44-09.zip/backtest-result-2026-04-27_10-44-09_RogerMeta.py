"""
Roger Meta-Strategy v1
Regime-switching multi-mode strategy for KuCoin crypto
3 modes: Trend Up, Chop (Mean Reversion), Bear (Cash/Short)
Dynamic position sizing + adaptive R/R per regime
"""

from freqtrade.strategy import IStrategy
from freqtrade.persistence import Trade
import pandas as pd
from pandas import DataFrame
import talib.abstract as ta
import numpy as np

class RogerMeta(IStrategy):
    timeframe = '1h'
    
    # Base risk parameters
    stoploss = -0.02
    trailing_stop = False
    use_custom_stoploss = True
    can_short = False
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    startup_candle_count = 200
    
    # --- REGIME DETECTION ---
    ema_trend_period = 200
    ema_fast_period = 9
    ema_slow_period = 21
    adx_period = 14
    adx_trend_threshold = 25
    adx_chop_threshold = 20
    atr_period = 14
    
    # --- MODE: TREND FOLLOWING ---
    trend_volume_mult = 1.0
    trend_rr_target = 0.05      # 5% target (2.5:1 R:R)
    trend_trail_atr_mult = 2.0
    trend_max_position_pct = 0.40  # 40% of capital
    
    # --- MODE: MEAN REVERSION (from RogerHybrid) ---
    mr_rsi_entry = 35
    mr_rsi_oversold = 30
    mr_rsi_exit = 70
    mr_volume_mult = 1.5
    mr_order_block_lookback = 50
    mr_order_block_atr_mult = 2.0
    mr_rr_target = 0.03         # 3% target (1.5:1 R:R)
    mr_max_position_pct = 0.35  # 35% of capital
    
    # --- MODE: BEAR / HIGH VOLATILITY ---
    bear_max_position_pct = 0.0  # Cash only (no longs)
    
    # --- POSITION SIZING ---
    base_stake = 50.0
    confidence_high = 0.8       # Scale up above this
    confidence_low = 0.5        # Scale down below this
    scale_high_mult = 1.5       # 1.5x stake at high confidence
    scale_low_mult = 0.5        # 0.5x stake at low confidence
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Trend
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=self.ema_trend_period)
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=self.ema_fast_period)
        dataframe['ema21'] = ta.EMA(dataframe, timeperiod=self.ema_slow_period)
        
        # Regime
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=self.adx_period)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=self.atr_period)
        
        # Mean reversion
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_prev'] = dataframe['rsi'].shift(1)
        dataframe['volume_avg20'] = dataframe['volume'].rolling(20).mean()
        
        # Regime classification
        dataframe['price_above_ema200'] = dataframe['close'] > dataframe['ema200']
        dataframe['ema9_above_21'] = dataframe['ema9'] > dataframe['ema21']
        dataframe['is_trending'] = dataframe['adx'] > self.adx_trend_threshold
        dataframe['is_choppy'] = dataframe['adx'] < self.adx_chop_threshold
        
        # Regime signal (0=chop/mr, 1=trend up, -1=trend down/bear)
        dataframe['regime'] = 0
        dataframe.loc[dataframe['is_trending'] & dataframe['price_above_ema200'], 'regime'] = 1
        dataframe.loc[dataframe['is_trending'] & ~dataframe['price_above_ema200'], 'regime'] = -1
        
        # Confidence (how clear is the regime?)
        dataframe['regime_confidence'] = dataframe['adx'] / 50.0  # normalize ADX
        dataframe['regime_confidence'] = dataframe['regime_confidence'].clip(0.0, 1.0)
        
        # Mean reversion: order blocks
        dataframe = self._detect_order_blocks(dataframe)
        
        return dataframe
    
    def _detect_order_blocks(self, df: DataFrame) -> DataFrame:
        df['order_block_zone'] = False
        df['order_block_low'] = np.nan
        df['order_block_high'] = np.nan
        
        for i in range(self.mr_order_block_lookback, len(df)):
            if i < self.mr_order_block_lookback + 1:
                continue
            bc = df.iloc[i - self.mr_order_block_lookback]
            if bc['close'] >= bc['open']:
                continue
            fs = df.iloc[i - self.mr_order_block_lookback + 1:i + 1]
            if len(fs) < 2:
                continue
            mm = (fs['high'].max() - bc['close']) / bc['close']
            at = bc['atr'] * self.mr_order_block_atr_mult / bc['close']
            if mm > at:
                df.loc[df.index[i], 'order_block_zone'] = True
                df.loc[df.index[i], 'order_block_low'] = bc['low']
                df.loc[df.index[i], 'order_block_high'] = bc['high']
        return df
    
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''
        dataframe['meta_mode'] = ''
        
        for i in range(1, len(dataframe)):
            regime = dataframe['regime'].iloc[i]
            confidence = dataframe['regime_confidence'].iloc[i]
            
            # Skip if regime is unclear
            if confidence < self.confidence_low:
                continue
            
            if regime == 1:
                # TREND MODE: EMA crossover
                prev_cross = dataframe['ema9'].iloc[i-1] <= dataframe['ema21'].iloc[i-1]
                curr_cross = dataframe['ema9'].iloc[i] > dataframe['ema21'].iloc[i]
                vol_ok = dataframe['volume'].iloc[i] > dataframe['volume_avg20'].iloc[i] * self.trend_volume_mult
                
                if prev_cross and curr_cross and vol_ok:
                    stake = self._calculate_stake(confidence, self.trend_max_position_pct)
                    dataframe.loc[dataframe.index[i], 'enter_long'] = 1
                    dataframe.loc[dataframe.index[i], 'enter_tag'] = f'meta_trend|stake={stake}'
                    dataframe.loc[dataframe.index[i], 'meta_mode'] = 'trend'
                    
            elif regime == 0:
                # CHOP MODE: Mean reversion (RogerHybrid style)
                rsi_cross = (
                    dataframe['rsi_prev'].iloc[i] < self.mr_rsi_entry and
                    dataframe['rsi'].iloc[i] >= self.mr_rsi_entry and
                    dataframe['rsi_prev'].iloc[i] < self.mr_rsi_oversold
                )
                if not rsi_cross:
                    continue
                
                ob_zone = False
                ob_low = None
                for j in range(max(0, i - self.mr_order_block_lookback), i):
                    if dataframe['order_block_zone'].iloc[j]:
                        bl = dataframe['order_block_low'].iloc[j]
                        bh = dataframe['order_block_high'].iloc[j]
                        if pd.notna(bl) and pd.notna(bh):
                            cp = dataframe['close'].iloc[i]
                            if bl * 0.98 <= cp <= bh * 1.02:
                                ob_zone = True
                                ob_low = bl
                                break
                
                vol_ok = dataframe['volume'].iloc[i] > dataframe['volume_avg20'].iloc[i] * self.mr_volume_mult
                
                if rsi_cross and ob_zone and vol_ok:
                    stake = self._calculate_stake(confidence, self.mr_max_position_pct)
                    dataframe.loc[dataframe.index[i], 'enter_long'] = 1
                    dataframe.loc[dataframe.index[i], 'enter_tag'] = f'meta_mr|ob_low={ob_low:.4f}|stake={stake}'
                    dataframe.loc[dataframe.index[i], 'meta_mode'] = 'mean_reversion'
            
            elif regime == -1:
                # BEAR MODE: No long entries (cash)
                pass
        
        return dataframe
    
    def _calculate_stake(self, confidence: float, max_pct: float) -> float:
        """Dynamic position sizing based on regime confidence"""
        if confidence >= self.confidence_high:
            mult = self.scale_high_mult
        elif confidence >= self.confidence_low:
            mult = 1.0
        else:
            mult = self.scale_low_mult
        
        # Cap at max_pct of theoretical $1000 wallet
        max_stake = 1000.0 * max_pct
        raw_stake = self.base_stake * mult
        return min(raw_stake, max_stake)
    
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        for i in range(1, len(dataframe)):
            # Mean reversion: RSI > 70
            if dataframe['rsi'].iloc[i] > self.mr_rsi_exit:
                dataframe.loc[dataframe.index[i], 'exit_long'] = 1
        return dataframe
    
    def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit, after_fill, **kwargs):
        """Regime-aware stoploss"""
        if not trade.enter_tag:
            return self.stoploss
        
        # Trend mode: wider trailing stop
        if 'meta_trend' in trade.enter_tag:
            # Use ATR-based dynamic stop
            # This is simplified - in production we'd track ATR at entry
            return -0.03  # 3% for trends
        
        # Mean reversion: OB-based stop
        if 'meta_mr' in trade.enter_tag and 'ob_low=' in trade.enter_tag:
            try:
                ob_low = float(trade.enter_tag.split('ob_low=')[1].split('|')[0])
                stop_pct = (current_rate - ob_low * 0.998) / current_rate
                return -max(stop_pct, 0.005)
            except:
                pass
        
        return self.stoploss
    
    def custom_exit(self, pair, trade, current_time, current_rate, current_profit, **kwargs):
        """Regime-aware profit targets"""
        if not trade.enter_tag:
            return None
        
        if 'meta_trend' in trade.enter_tag:
            # Trend: bigger target, then trail
            if current_profit >= self.trend_rr_target:
                return 'meta_tp_trend'
        
        elif 'meta_mr' in trade.enter_tag:
            # Mean reversion: fixed target
            if current_profit >= self.mr_rr_target:
                return 'meta_tp_mr'
        
        return None
    
    def confirm_trade_entry(self, pair: str, order_type: str, amount: float, rate: float,
                            time_in_force: str, current_time, entry_tag: str, side: str,
                            **kwargs) -> bool:
        """Final check: respect regime-specific allocation limits"""
        if not entry_tag:
            return True
        
        # Count open trades by mode
        open_trades = Trade.get_trades_proxy(is_open=True)
        trend_trades = sum(1 for t in open_trades if t.enter_tag and 'meta_trend' in t.enter_tag)
        mr_trades = sum(1 for t in open_trades if t.enter_tag and 'meta_mr' in t.enter_tag)
        
        if 'meta_trend' in entry_tag and trend_trades >= 2:
            return False
        if 'meta_mr' in entry_tag and mr_trades >= 2:
            return False
        
        return True
